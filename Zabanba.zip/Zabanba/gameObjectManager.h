//==============================================================================
// 
// �Q�[���I�u�W�F�N�g�}�l�[�W��[gameObjectManager.h]
// Auther: KOUTAROUNISIDA
// 
//==============================================================================

//==============================================================================
// �C���N���[�h�K�[�h
//==============================================================================
#ifndef __GAMEOBJECTMANAGER_H_
#define __GAMEOBJECTMANAGER_H_
//==============================================================================
// �C���N���[�h
//==============================================================================
#include "content.h"

//==============================================================================
// �}�N����`
//==============================================================================

//==============================================================================
// �N���X
//==============================================================================
class GameObject;
class Device;

class GameObjectManager
{
public:
	GameObjectManager();
	~GameObjectManager();
	void Init(void);
	void Uninit(void);
	void Update(void);
	void Draw(void);
	void UpdateAll(void);
	void ReleaseAll(void);

	void CreateObject(void);
	bool CheckDelete(GameObject *gameobject);

	static GameObjectManager *Create(void);

	List<GameObject *> *GetGameObjetList(){ return m_GameObjectList; }
	void SetGameObjetList( List<GameObject *> *gameobjectlist ){ m_GameObjectList = gameobjectlist; }
private :
	List<GameObject *> *m_GameObjectList;
};

//==============================================================================
// �\���̒�`
//==============================================================================

//==============================================================================
// �v���g�^�C�v�錾
//==============================================================================
#endif
// EOF