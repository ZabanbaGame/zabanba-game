//==============================================================================
// 
// 2D�|���S��[mesh2D.cpp]
// Auther: KOUTAROU NISIDA
// 
//==============================================================================

//==============================================================================
// �C���N���[�h
//==============================================================================
#include "mesh2D.h"
#include "dataResources.h"
#include "meshData.h"
#include "mesh2DData.h"
#include "mesh3DData.h"
#include "meshModelData.h"

//==============================================================================
// �}�N����`
//==============================================================================

//==============================================================================
// �N���X
//==============================================================================

//==============================================================================
// �\���̒�`
//==============================================================================

//==============================================================================
// �O���[�o���ϐ�
//==============================================================================

//==============================================================================
// �ÓI�ϐ�
//==============================================================================

//==============================================================================
// �v���g�^�C�v�錾
//==============================================================================

//==============================================================================
// 2D�|���S���R���X�g���N�^
// ����:
// �ߒl:
//==============================================================================
Mesh2D::Mesh2D(GameObject *gameobject):RendererComposition(gameobject)
{
}

//==============================================================================
// 2D�|���S���f�X�g���N�^
// ����:
// �ߒl:
//==============================================================================
Mesh2D::~Mesh2D()
{
}

//==============================================================================
// 2D�|���S������
// ����:
// VECTOR3 position		:���W
// VECTOR3 rotation		:��]�p�x
// float width			:��
// float height			:����
// �ߒl:
//==============================================================================
Mesh2D *Mesh2D::Create(GameObject *gameobjcect,float width,float height)
{
	Mesh2D *pMesh2D = new Mesh2D(gameobjcect);
	pMesh2D->Init(width,height);

	return pMesh2D;
}

//==============================================================================
// 2D�|���S������������
// ����:
// �ߒl:
//==============================================================================
HRESULT Mesh2D::Init(float width,float height)
{
	// �f�[�^�[�̎擾
	m_Mesh2DData = m_DataResouces->GetMeshData()->GetMesh2DData();

	m_Transform.Init();
	m_Width = width;
	m_Height = height;

	// �Ίp���̒����v�Z
	m_Length = sqrtf(m_Width * m_Height + m_Width * m_Height);
	
	// �Ίp���̊p�x�v�Z
	m_Angle = atan2f(m_Width,m_Height);

	return S_OK;
}

//==============================================================================
// 2D�|���S���I������
// ����:��
// �ߒl:��
//==============================================================================
void Mesh2D::Uninit(void)
{

}

//==============================================================================
// 2D�|���S���X�V����
// ����:��
// �ߒl:��
//==============================================================================
void Mesh2D::Update(void)
{
}

//==============================================================================
// 2D�|���S���`�揈��
// ����:��
// �ߒl:��
//==============================================================================
void Mesh2D::Draw(void)
{
	// ���_�̐ݒ�
	SetVertex( m_Transform );

	// ���_�o�b�t�@���f�[�^�X�g���[���Ƀo�C���h
	m_Device->SetStreamSource( 0,m_Mesh2DData->GetVertexBuff(),0,sizeof(VERTEX_2D) );

	// ���_�t�H�[�}�b�g�̐ݒ�
	m_Device-> SetFVF( FVF_VERTEX_2D );

	// �e�N�X�`���̓\��t��
	m_Device->SetTexture( 0,NULL );

	// �l�p�`�̕`��	����3�@�v���~�e�B�u�̎�ށA0,(�|���S��)�v���~�e�B�u����
	m_Device->DrawPrimitive( D3DPT_TRIANGLESTRIP,0,2 );
}

//==============================================================================
// ���_�̐ݒ�
// ����:
// Transform transform
// �ߒl:��
//==============================================================================
void Mesh2D::SetVertex(Transform transform)
{
	VERTEX_2D *pVtx = NULL;
	m_Mesh2DData->Lock(&pVtx);
	//m_Mesh2DData->GetVertexBuff()->Lock( 0,0,(void **)&pVtx,0 );

	pVtx[0].vtx = VECTOR3(transform.m_Position.x - sinf(transform.m_Rotation.z + m_Angle) * m_Length, transform.m_Position.y - cosf(transform.m_Rotation.z + m_Angle) * m_Length, 0.0f);
	pVtx[1].vtx = VECTOR3(transform.m_Position.x + sinf(transform.m_Rotation.z + m_Angle) * m_Length, transform.m_Position.y - cosf(transform.m_Rotation.z + m_Angle) * m_Length, 0.0f);
	pVtx[2].vtx = VECTOR3(transform.m_Position.x - sinf(transform.m_Rotation.z + m_Angle) * m_Length, transform.m_Position.y + cosf(transform.m_Rotation.z + m_Angle) * m_Length, 0.0f);
	pVtx[3].vtx = VECTOR3(transform.m_Position.x + sinf(transform.m_Rotation.z + m_Angle) * m_Length, transform.m_Position.y + cosf(transform.m_Rotation.z + m_Angle) * m_Length, 0.0f);
	
	m_Mesh2DData->Unlock();
}

//==============================================================================
// ���_�̐ݒ�
// ����:
// VECTOR3 position		: ���W
// VECTOR3 rotation		: ��]
// �ߒl:��
//==============================================================================
void Mesh2D::SetVertex(VECTOR3 position,VECTOR3 rotation)
{
	VERTEX_2D *pVtx = NULL;
	m_Mesh2DData->Lock(&pVtx);

	pVtx[0].vtx = VECTOR3(position.x - sinf(rotation.z + m_Angle) * m_Length, position.y - cosf(rotation.z + m_Angle) * m_Length, 0.0f);
	pVtx[1].vtx = VECTOR3(position.x + sinf(rotation.z + m_Angle) * m_Length, position.y - cosf(rotation.z + m_Angle) * m_Length, 0.0f);
	pVtx[2].vtx = VECTOR3(position.x - sinf(rotation.z + m_Angle) * m_Length, position.y + cosf(rotation.z + m_Angle) * m_Length, 0.0f);
	pVtx[3].vtx = VECTOR3(position.x + sinf(rotation.z + m_Angle) * m_Length, position.y + cosf(rotation.z + m_Angle) * m_Length, 0.0f);
	
	m_Mesh2DData->Unlock();
}

//==============================================================================
// ���_�̐ݒ�
// ����:
// VECTOR3 vertex1		: ���_
// VECTOR3 vertex2		: 
// VECTOR3 vertex3		: 
// VECTOR3 vertex4		: 
// �ߒl:��
//==============================================================================
void Mesh2D::SetVertex(VECTOR3 vertex1,VECTOR3 vertex2,VECTOR3 vertex3,VECTOR3 vertex4)
{
	VERTEX_2D *pVtx = NULL;
	m_Mesh2DData->Lock(&pVtx);

	pVtx[0].vtx = vertex1;
	pVtx[1].vtx = vertex2;
	pVtx[2].vtx = vertex3;
	pVtx[3].vtx = vertex4;
	
	m_Mesh2DData->Unlock();
}

// EOF