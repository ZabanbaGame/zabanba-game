//==============================================================================
// 
// �}�g���b�N�X[matrix.cpp]
// Auther: KOUTAROUNISIDA
// 
//==============================================================================

//==============================================================================
// �C���N���[�h
//==============================================================================
#include "matrix.h"
#include <math.h>
#include <Windows.h>
#include "d3dx9.h"
//==============================================================================
// �}�N����`
//==============================================================================
#define RadsToDegrees( radian ) ((radian) * (180.0f / PI))		// �x�ɕϊ�
#define DegreesToRads( degrees ) ((degrees) * (PI/ 180.0f))		// ���W�A���ɕϊ�

//==============================================================================
// �N���X
//==============================================================================

//==============================================================================
// �\���̒�`
//==============================================================================

//==============================================================================
// �O���[�o���ϐ�
//==============================================================================

//==============================================================================
// �I�[�o�[���C�h
//==============================================================================

//==============================================================================
// �v���g�^�C�v�錾
//==============================================================================

//*************************************
// 3X3�̍s��
//*************************************

//==============================================================================
// 3x3�}�g���b�N�X�R���X�g���N�^
// ����:
// �ߒl:
//==============================================================================
MATRIX3::MATRIX3(float f11,float f12,float f13,
		float f21,float f22,float f23,
		float f31,float f32,float f33)
{
	m11 = f11, m12 = f12, m13 = f13;
	m21 = f21, m22 = f22, m23 = f23;
	m31 = f31, m32 = f32, m33 = f33;
}

//==============================================================================
// �s��̑����Z����
// ����:�ݒ肵�����s��
// �ߒl:��
//==============================================================================
MATRIX3 MATRIX3::operator + (const MATRIX3& Mat) const
{
	return MATRIX3( m11 + Mat.m11, m12 + Mat.m12, m13 + Mat.m13,
					m21 + Mat.m21, m22 + Mat.m22, m23 + Mat.m23,
					m31 + Mat.m31, m32 + Mat.m32, m33 + Mat.m33);
}

//==============================================================================
// �s��̃X�J���[�{����
// ����:�ݒ肵�����s��
// �ߒl:��
//==============================================================================
MATRIX3 MATRIX3::operator * (float f) const
{
	return MATRIX3( m11 * f, m12 * f, m13 * f,
					m21 * f, m22 * f, m23 * f, 
					m31 * f, m32 * f, m33 * f);
}

//==============================================================================
// �s��ƍs��̐Ϗ���
// ����:�ݒ肵�����s��
// �ߒl:��
//==============================================================================
MATRIX3 MATRIX3::operator * (const MATRIX3& Mat) const
{
	float s11, s12, s13;
	float s21, s22, s23;
	float s31, s32, s33;

	s11 = ( m11 * Mat.m11 ) + ( m12 * Mat.m21 ) + ( m13 * Mat.m31 );
	s12 = ( m11 * Mat.m12 ) + ( m12 * Mat.m22 ) + ( m13 * Mat.m32 );
	s13 = ( m11 * Mat.m13 ) + ( m12 * Mat.m23 ) + ( m13 * Mat.m33 );

	s21 = m21 * ( Mat.m11 ) + ( m22 * Mat.m21 ) + ( m23 * Mat.m31 );
	s22 = m21 * ( Mat.m12 ) + ( m22 * Mat.m22 ) + ( m23 * Mat.m32 );
	s23 = m21 * ( Mat.m13 ) + ( m22 * Mat.m23 ) + ( m23 * Mat.m33 );

	s31 = m31 * ( Mat.m11 ) + ( m32 * Mat.m21 ) + ( m33 * Mat.m31 );
	s32 = m31 * ( Mat.m12 ) + ( m32 * Mat.m22 ) + ( m33 * Mat.m32 );
	s33 = m31 * ( Mat.m13 ) + ( m32 * Mat.m23 ) + ( m33 * Mat.m33 );

	return MATRIX3(  s11,s12,s13,
					s21,s22,s23,
					s31,s32,s33);
}

//=============================================================================
// �s��̏�����
// ����:�o�͗p�ϐ�
// �ߒl:��
//=============================================================================
void MATRIX3::Identity(MATRIX3 *out)
{
	out->m11 = 1.0f, out->m12 = 0.0f, out->m13 = 0.0f;
	out->m21 = 0.0f, out->m22 = 1.0f, out->m23 = 0.0f;
	out->m31 = 0.0f, out->m32 = 0.0f, out->m33 = 1.0f;
}

//=============================================================================
// �ړ�
// ����:
// �ߒl:
//=============================================================================
void MATRIX3::Translation(MATRIX3 *out,VECTOR3 *pos)
{
	// ����k
	Identity( out );

	out->m31 = pos->x;
	out->m32 = pos->y;
}

//=============================================================================
// �g��E�k��
// ����:
// �ߒl:
//=============================================================================
void MATRIX3::Scaling( MATRIX3 *out, VECTOR3 *scl )
{
	Identity( out );

	out->m11 = scl->x;
	out->m22 = scl->y;
}

//=============================================================================
// ��]
// ����:
// �ߒl:
//=============================================================================
void MATRIX3::Rotation(MATRIX3 *out, float fAngle )
{
	// �s��̏�����
	Identity( out );

	float st, ct;

	st = sinf( fAngle );
	ct = cosf( fAngle );

	out->m11 = ct;
	out->m12 = -st;
	out->m21 = st;
	out->m22 = ct;
}

//=============================================================================
// �s��̏�Z
// ����:
// �ߒl:
//=============================================================================
void MATRIX3::Multiply( MATRIX3 *out, MATRIX3 *Matrix1, MATRIX3 *Matrix2 )
{
	MATRIX3 matrix;

	matrix.m11 = Matrix1->m11 * Matrix2->m11 + Matrix1->m12 * Matrix2->m21 + Matrix1->m13 * Matrix2->m31;
	matrix.m12 = Matrix1->m11 * Matrix2->m12 + Matrix1->m12 * Matrix2->m22 + Matrix1->m13 * Matrix2->m32;
	matrix.m13 = Matrix1->m11 * Matrix2->m13 + Matrix1->m12 * Matrix2->m23 + Matrix1->m13 * Matrix2->m33;

	matrix.m21 = Matrix1->m21 * Matrix2->m11 + Matrix1->m22 * Matrix2->m21 + Matrix1->m23 * Matrix2->m31;
	matrix.m22 = Matrix1->m21 * Matrix2->m12 + Matrix1->m22 * Matrix2->m22 + Matrix1->m23 * Matrix2->m32;
	matrix.m23 = Matrix1->m21 * Matrix2->m13 + Matrix1->m22 * Matrix2->m23 + Matrix1->m23 * Matrix2->m33;

	matrix.m31 = Matrix1->m31 * Matrix2->m11 + Matrix1->m32 * Matrix2->m21 + Matrix1->m33 * Matrix2->m31;
	matrix.m32 = Matrix1->m31 * Matrix2->m12 + Matrix1->m32 * Matrix2->m22 + Matrix1->m33 * Matrix2->m32;
	matrix.m33 = Matrix1->m31 * Matrix2->m13 + Matrix1->m32 * Matrix2->m23 + Matrix1->m33 * Matrix2->m33;

	*out = matrix;
}

//=============================================================================
// ���W�ϊ�
// ����:
// �ߒl:
//=============================================================================
void MATRIX3::Vector3Transform( VECTOR3 *out, VECTOR3 *Vector, MATRIX3 *Matrix )
{
	out->x = Matrix->m11 * Vector->x + Matrix->m21 * Vector->y + Matrix->m31;
	out->y = Matrix->m12 * Vector->x + Matrix->m22 * Vector->y + Matrix->m32;
}

//*************************************
// 4X4�̍s��
//*************************************

//==============================================================================
// 4x4�}�g���b�N�X�R���X�g���N�^
// ����:
// �ߒl:
//==============================================================================
MATRIX4::MATRIX4(float f11,float f12,float f13,float f14,
		float f21,float f22,float f23,float f24,
		float f31,float f32,float f33,float f34,
		float f41,float f42,float f43,float f44)
{
	m11 = f11, m12 = f12, m13 = f13, m14 = f14;
	m21 = f21, m22 = f22, m23 = f23, m24 = f24;
	m31 = f31, m32 = f32, m33 = f33, m34 = f34;
	m41 = f41, m42 = f42, m43 = f43, m44 = f44;
}

//==============================================================================
// �s��̑����Z����
// ����:�ݒ肵�����s��
// �ߒl:��
//==============================================================================
MATRIX4 MATRIX4::operator + (const MATRIX4& Mat) const
{
	return MATRIX4( m11 + Mat.m11, m12 + Mat.m12, m13 + Mat.m13, m14 + Mat.m14,
					m21 + Mat.m21, m22 + Mat.m22, m23 + Mat.m23, m24 + Mat.m24,
					m31 + Mat.m31, m32 + Mat.m32, m33 + Mat.m33, m34 + Mat.m34,
					m41 + Mat.m41, m42 + Mat.m42, m43 + Mat.m43, m44 + Mat.m44);
}

//==============================================================================
// �s��̃X�J���[�{����
// ����:�ݒ肵�����s��
// �ߒl:��
//==============================================================================
MATRIX4 MATRIX4::operator * (float f) const
{
	return MATRIX4( m11 * f, m12 * f, m13 * f, m14 * f,
					m21 * f, m22 * f, m23 * f, m24 * f,
					m31 * f, m32 * f, m33 * f, m34 * f,
					m41 * f, m42 * f, m43 * f, m44 * f);
}

//==============================================================================
// �s��ƍs��̐Ϗ���
// ����:�ݒ肵�����s��
// �ߒl:��
//==============================================================================
MATRIX4 MATRIX4::operator * (const MATRIX4& Mat) const
{
	float s11, s12, s13, s14;
	float s21, s22, s23, s24;
	float s31, s32, s33, s34;
	float s41, s42, s43, s44;

	s11 = ( m11 * Mat.m11 ) + ( m12 * Mat.m21 ) + ( m13 * Mat.m31 ) + ( m14 * Mat.m41 );
	s12 = ( m11 * Mat.m12 ) + ( m12 * Mat.m22 ) + ( m13 * Mat.m32 ) + ( m14 * Mat.m42 );
	s13 = ( m11 * Mat.m13 ) + ( m12 * Mat.m23 ) + ( m13 * Mat.m33 ) + ( m14 * Mat.m43 );
	s14 = ( m11 * Mat.m14 ) + ( m12 * Mat.m24 ) + ( m13 * Mat.m34 ) + ( m14 * Mat.m44 );

	s21 = m21 * ( Mat.m11 ) + ( m22 * Mat.m21 ) + ( m23 * Mat.m31 ) + ( m24 * Mat.m41 );
	s22 = m21 * ( Mat.m12 ) + ( m22 * Mat.m22 ) + ( m23 * Mat.m32 ) + ( m24 * Mat.m42 );
	s23 = m21 * ( Mat.m13 ) + ( m22 * Mat.m23 ) + ( m23 * Mat.m33 ) + ( m24 * Mat.m43 );
	s24 = m21 * ( Mat.m14 ) + ( m22 * Mat.m24 ) + ( m23 * Mat.m34 ) + ( m24 * Mat.m44 );

	s31 = m31 * ( Mat.m11 ) + ( m32 * Mat.m21 ) + ( m33 * Mat.m31 ) + ( m34 * Mat.m41 );
	s32 = m31 * ( Mat.m12 ) + ( m32 * Mat.m22 ) + ( m33 * Mat.m32 ) + ( m34 * Mat.m42 );
	s33 = m31 * ( Mat.m13 ) + ( m32 * Mat.m23 ) + ( m33 * Mat.m33 ) + ( m34 * Mat.m43 );
	s34 = m31 * ( Mat.m14 ) + ( m32 * Mat.m24 ) + ( m33 * Mat.m34 ) + ( m34 * Mat.m44 );

	s41 = m41 * ( Mat.m11 ) + ( m42 * Mat.m21 ) + ( m43 * Mat.m31 ) + ( m44 * Mat.m41 );
	s42 = m41 * ( Mat.m12 ) + ( m42 * Mat.m22 ) + ( m43 * Mat.m32 ) + ( m44 * Mat.m42 );
	s43 = m41 * ( Mat.m13 ) + ( m42 * Mat.m23 ) + ( m43 * Mat.m33 ) + ( m44 * Mat.m43 );
	s44 = m41 * ( Mat.m14 ) + ( m42 * Mat.m24 ) + ( m43 * Mat.m34 ) + ( m44 * Mat.m44 );

	return MATRIX4(  s11,s12,s13,s14,
					s21,s22,s23,s24,
					s31,s32,s33,s34,
					s41,s42,s43,s44);
}

//=============================================================================
// �s��̏�����
// ����:�o�͗p�ϐ�
// �ߒl:��
//=============================================================================
void Matrix4Identity(MATRIX4 *out)
{
	out->m11 = 1.0f, out->m12 = 0.0f, out->m13 = 0.0f, out->m14 = 0.0f;
	out->m21 = 0.0f, out->m22 = 1.0f, out->m23 = 0.0f, out->m24 = 0.0f;
	out->m31 = 0.0f, out->m32 = 0.0f, out->m33 = 1.0f, out->m34 = 0.0f;
	out->m41 = 0.0f, out->m42 = 0.0f, out->m43 = 0.0f, out->m44 = 1.0f;
}

//=============================================================================
// �ړ�
// ����:
// �ߒl:
//=============================================================================
void Matrix4Translation(MATRIX4 *out,float x,float y,float z)
{
	// ����k
	Matrix4Identity( out );

	out->m41 = x;
	out->m42 = y;
	out->m43 = z;
}

//=============================================================================
// �g�k
// ����:
// �ߒl:
//=============================================================================
void Matrix4Scaling( MATRIX4 *out,float x,float y,float z )
{
	MATRIX4 temp;
	Matrix4Identity(out);

	out->M[0][0] = x;
	out->M[1][1] = y;
	out->M[2][2] = z;
	out->M[3][3] = 1;

}

//=============================================================================
// ��]
// ����:
// �ߒl:
//=============================================================================
void Matrix4Rotation(MATRIX4 *out, float fAngle )
{
}

//=============================================================================
// �s��̏�Z
// ����:
// �ߒl:
//=============================================================================
void Matrix4Multiply( MATRIX4 *out, MATRIX4 *Matrix1, MATRIX4 *Matrix2 )
{
	MATRIX4 matrix;

	memset(&matrix,0,sizeof(matrix));

	for( int i = 0; i < 4; i++ )
	{
		for( int j = 0; j < 4; j++ )
		{
			for( int k = 0; k < 4; k++ )
			{
				matrix.M[i][j] += (Matrix1->M[i][k] * Matrix2->M[k][j] );
			}
		}
	}

	//matrix.m11 = Matrix1->m11 * Matrix2->m11 + Matrix1->m12 * Matrix2->m21 + Matrix1->m13 * Matrix2->m31 + Matrix1->m14 * Matrix2->m41;
	//matrix.m12 = Matrix1->m11 * Matrix2->m12 + Matrix1->m12 * Matrix2->m22 + Matrix1->m13 * Matrix2->m32 + Matrix1->m14 * Matrix2->m42;
	//matrix.m13 = Matrix1->m11 * Matrix2->m13 + Matrix1->m12 * Matrix2->m23 + Matrix1->m13 * Matrix2->m33 + Matrix1->m14 * Matrix2->m43;
	//matrix.m14 = Matrix1->m11 * Matrix2->m14 + Matrix1->m12 * Matrix2->m24 + Matrix1->m13 * Matrix2->m34 + Matrix1->m14 * Matrix2->m44;
	//
	//matrix.m21 = Matrix1->m21 * Matrix2->m11 + Matrix1->m22 * Matrix2->m21 + Matrix1->m23 * Matrix2->m31 + Matrix1->m24 * Matrix2->m41;
	//matrix.m22 = Matrix1->m21 * Matrix2->m12 + Matrix1->m22 * Matrix2->m22 + Matrix1->m23 * Matrix2->m32 + Matrix1->m24 * Matrix2->m42;
	//matrix.m23 = Matrix1->m21 * Matrix2->m13 + Matrix1->m22 * Matrix2->m23 + Matrix1->m23 * Matrix2->m33 + Matrix1->m24 * Matrix2->m43;
	//matrix.m23 = Matrix1->m21 * Matrix2->m14 + Matrix1->m22 * Matrix2->m24 + Matrix1->m23 * Matrix2->m34 + Matrix1->m24 * Matrix2->m44;
	//
	//matrix.m31 = Matrix1->m31 * Matrix2->m11 + Matrix1->m32 * Matrix2->m21 + Matrix1->m33 * Matrix2->m31 + Matrix1->m34 * Matrix2->m41;
	//matrix.m32 = Matrix1->m31 * Matrix2->m12 + Matrix1->m32 * Matrix2->m22 + Matrix1->m33 * Matrix2->m32 + Matrix1->m34 * Matrix2->m42;
	//matrix.m33 = Matrix1->m31 * Matrix2->m13 + Matrix1->m32 * Matrix2->m23 + Matrix1->m33 * Matrix2->m33 + Matrix1->m34 * Matrix2->m43;
	//matrix.m33 = Matrix1->m31 * Matrix2->m14 + Matrix1->m32 * Matrix2->m24 + Matrix1->m33 * Matrix2->m34 + Matrix1->m34 * Matrix2->m44;
	//
	//matrix.m41 = Matrix1->m41 * Matrix2->m11 + Matrix1->m42 * Matrix2->m21 + Matrix1->m43 * Matrix2->m31 + Matrix1->m44 * Matrix2->m41;
	//matrix.m42 = Matrix1->m41 * Matrix2->m12 + Matrix1->m42 * Matrix2->m22 + Matrix1->m43 * Matrix2->m32 + Matrix1->m44 * Matrix2->m42;
	//matrix.m43 = Matrix1->m41 * Matrix2->m13 + Matrix1->m42 * Matrix2->m23 + Matrix1->m43 * Matrix2->m33 + Matrix1->m44 * Matrix2->m43;
	//matrix.m43 = Matrix1->m41 * Matrix2->m14 + Matrix1->m42 * Matrix2->m24 + Matrix1->m43 * Matrix2->m34 + Matrix1->m44 * Matrix2->m44;

	*out = matrix;
}

//=============================================================================
// ���W�ϊ�
// ����:
// �ߒl:
//=============================================================================
void Matrix4Vector3Transform( VECTOR3 *out, VECTOR3 *Vector, MATRIX4 *Matrix )
{
	out->x = Matrix->m11 * Vector->x + Matrix->m21 * Vector->y + Matrix->m31 * Vector->z + Matrix->m41;
	out->y = Matrix->m12 * Vector->x + Matrix->m22 * Vector->y + Matrix->m32 * Vector->z + Matrix->m42;
	out->z = Matrix->m13 * Vector->x + Matrix->m23 * Vector->y + Matrix->m33 * Vector->z + Matrix->m43;
}

//=============================================================================
// �]�u�s��
// ����:
// �ߒl:
//=============================================================================
void Matrix4Transpose( MATRIX4 *Out, MATRIX4 *Matrix1 )
{
	for( int i = 0; i < 4; i++ )
	{
		for( int j = 0 ; j < 4; j++ )
		{
			Out->M[i][j] = Matrix1->M[j][i];
		}
	}
}

//=============================================================================
// ��]�s��̍쐬
// ����:
// �ߒl:
//=============================================================================
void Matrix4RotationYawPitchRoll(MATRIX4 *Out, float yaw, float pitch, float roll)
{
	MATRIX4 X,Y,Z,temp;

	Matrix4Zero(&X);
	Matrix4Zero(&Y);
	Matrix4Zero(&Z);
	Matrix4Zero(&temp);
	Matrix4Zero(Out);

	// X������̉�]�s��
	X.M[0][0] = 1;
	X.M[1][1] = cos(pitch);
	X.M[2][2] = cos(pitch);
	X.M[3][3] = 1;
	
	X.M[1][2] = -1*(sin(pitch));
	X.M[2][1] = sin(pitch);
	
	// Y������̉�]�s��
	Y.M[0][0] = cos(yaw);
	Y.M[1][1] = 1;
	Y.M[2][2] = cos(yaw);
	Y.M[3][3] = 1;
	
	Y.M[2][0] = -1*(sin(yaw));
	Y.M[0][2] = sin(yaw);
	
	// Z������̉�]�s��
	Z.M[0][0]  = cos(roll);
	Z.M[1][1]  = cos(roll);
	Z.M[2][2]  = 1;
	Z.M[3][3]  = 1;
	
	Z.M[0][1]  = -1*(sin(roll));
	Z.M[1][0]  = sin(roll);

	// �g�ݍ��킹�s��̍쐬
	Matrix4Multiply(&temp,&Y,&X);

	Matrix4Multiply(Out,&temp,&Z);
}


//=============================================================================
// ��]�s��̍쐬
// ����:
// �ߒl:
//=============================================================================
//void CreateRotation(MATRIX4 *Out,float thetaX,float thetaY,float thetaZ)
//{
//	MATRIX4 X,Y,Z,temp;
//
//	Zero(&X);
//	Zero(&Y);
//	Zero(&Z);
//	Zero(&temp);
//	Zero(Out);
//
//	// X������̉�]�s��
//	X.M[0][0] = 1;
//	X.M[1][1] = cos(thetaX);
//	X.M[2][2] = cos(thetaX);
//	X.M[3][3] = 1;
//	
//	X.M[1][2] = -1*(sin(thetaX));
//	X.M[2][1] = sin(thetaX);
//	
//	// Y������̉�]�s��
//	Y.M[0][0] = cos(thetaY);
//	Y.M[1][1] = 1;
//	Y.M[2][2] = cos(thetaY);
//	Y.M[3][3] = 1;
//	
//	Y.M[2][0] = -1*(sin(thetaY));
//	Y.M[0][2] = sin(thetaY);
//	
//	// Z������̉�]�s��
//	Z.M[0][0]  = cos(thetaZ);
//	Z.M[1][1]  = cos(thetaZ);
//	Z.M[2][2]  = 1;
//	Z.M[3][3]  = 1;
//	
//	Z.M[0][1]  = -1*(sin(thetaZ));
//	Z.M[1][0]  = sin(thetaZ);
//
//	// �g�ݍ��킹�s��̍쐬
//	Multiply(&temp,&Y,&X);
//
//	Multiply(Out,&temp,&Z);
//}

//=============================================================================
// �t�s��
// ����:
// �ߒl:
//=============================================================================
void Matrix4Inverse(MATRIX4 *Out,MATRIX4 *Matrix)
{
	MATRIX4 Mat = *Matrix;

	float buf; //�ꎞ�I�ȃf�[�^��~����

	int i,j,k; //�J�E���^
	int n = 4;  //�z��̎���<br />

	//�P�ʍs��
	Matrix4Identity(Out);

//	for( k=0; k<n; k++){
//			//�s�{�b�g�I�� k�sk��ڂ̗v�f�̐�Βl���ő��
//			int max = k;
//			for( j=k+1; j<n; j++)
//			{
//				if( fabs(Mat.M[j][k]) > fabs(Mat.M[max][k]) )
//				{
//					max = j;
//				}
//			}
//			// �s�̓���ւ�
//			if( max != k ){
//			for( i=0; i<n; i++ )
//			{
//				// ���͍s��
//				buf = Mat.M[max][i];
//				Mat.M[max][i] = Mat.M[k][i];
//				Mat.M[k][i] = buf;
//				// �P�ʍs��
//				buf = Out->M[max][i];
//				Out->M[max][i] = Out->M[k][i];
//				Out->M[k][i] = buf;
//				}
//	         }
//	         // k�sk��ڂ̗v�f��1�ɂȂ�悤��
//	         buf = Mat.M[k][k];
//	         for(i=0;i<n;i++){
//	                 Mat.M[k][i] /= buf;
//	                 Out->M[k][i] /= buf;
//	         }
//	         // k�s�ڂ�k��ڈȊO�̗v�f��0�ɂȂ�悤��
//	         for( j=0;j<n;j++ ){
//	                 if( j != k ){
//	                         buf = Mat.M[j][k] / Mat.M[k][k];
//	                         for(i=0;i<n;i++){
//	                                 Mat.M[j][i] = Mat.M[j][i] - Mat.M[k][i] * buf;
//	                                 Out->M[j][i] = Out->M[j][i] - Out->M[k][i] * buf;
//	                         }
//	                 }
//	         }
//	
//	 }
//	 for( j=0; j<n; j++ ){
//	         for( i=0; i<n; i++ ){
//				 Out->f[ i+n*j ] = Out->M[j][i];
//	         }
//	 }


	//�|���o���@
	for(i=0;i<n;i++)
	{
		buf=1 / Mat.M[i][i];
		for(j=0;j<n;j++)
		{
			Mat.M[i][j] *= buf;
			Out->M[i][j] *= buf;
		}
		for(j=0;j<n;j++)
		{
			if(i!=j)
			{
				buf = Mat.M[j][i];
				for(k = 0; k < n; k++)
				{
					Mat.M[j][k] -= Mat.M[i][k] * buf;
					Out->M[j][k] -= Out->M[i][k]*buf;
				}
			}
		}
	}
}

//=============================================================================
// MATRIX4����D3DMATRIX�ɕϊ�
// ����:MATRIX4�̒l
// �ߒl:D3DXMATRIX�̒l
//=============================================================================
MATRIX4::operator D3DXMATRIX () const
{
	D3DXMATRIX mat(f);

	return mat;
}

void Matrix4Zero(MATRIX4 *Out )
{
	memset(Out,0,sizeof(*Out));
}

// EOF