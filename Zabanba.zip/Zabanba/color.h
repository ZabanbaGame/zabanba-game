//=============================================================================
//
// �F [color.h]
// Author : KOUTAROU NISIDA
//
//=============================================================================
#ifndef _COLOR_H_		// �C���N���[�h�K�[�h
#define _COLOR_H_

//*****************************************************************************
// �C���N���[�h�t�@�C��
//*****************************************************************************
#include "device.h"

//*****************************************************************************
// ���C�u�����̃����N
//*****************************************************************************

//*****************************************************************************
// �}�N����`
//*****************************************************************************
#define COLOR_WHITE					(COLOR(1.000000f,1.000000f,1.000000f,1.000000f))			// ��
#define COLOR_BLACK					(COLOR(0.000000f,0.000000f,0.000000f,1.000000f))			// ��
#define COLOR_RED					(COLOR(1.000000f,0.000000f,0.000000f,1.000000f))			// ��
#define COLOR_GREEN					(COLOR(0.000000f,1.000000f,0.000000f,1.000000f))			// ��
#define COLOR_BLUE					(COLOR(0.000000f,0.000000f,1.000000f,1.000000f))			// ��
#define COLOR_YELLOW				(COLOR(1.000000f,1.000000f,0.000000f,1.000000f))			// ���F
#define COLOR_PURPLE				(COLOR(1.000000f,0.000000f,1.000000f,1.000000f))			// ��
#define COLOR_SKYBLUE				(COLOR(0.000000f,1.000000f,1.000000f,1.000000f))			// ���F

#define LIGHTCOLR_WHILE				(COLOR(0.500000f,0.500000f,0.500000f,1.000000f))			// ������
#define LIGHTCOLOR_RED				(COLOR(0.500000f,0.000000f,0.000000f,1.000000f))			// ������
#define LIGHTCOLOR_GREEN			(COLOR(0.000000f,0.500000f,0.000000f,1.000000f))			// ������
#define LIGHTCOLOR_BLUE				(COLOR(0.000000f,0.000000f,0.500000f,1.000000f))			// ������
#define LIGHTCOLOR_YELLOW			(COLOR(0.500000f,0.500000f,0.000000f,1.000000f))			// �������F
#define LIGHTCOLOR_PURPLE			(COLOR(0.500000f,0.000000f,0.500000f,1.000000f))			// ������
#define LIGHTCOLOR_SKYBLUE			(COLOR(0.000000f,0.500000f,0.500000f,1.000000f))			// �������F
#define HALFCOLOR_ALPHA				(COLOR(0.000000f,0.000000f,0.000000f,0.500000f))			// ������

// ����
#define COLOR_WHITE_NO_ALPHA		(COLOR(1.0f,1.0f,1.0f,0.0f))			// ��
#define COLOR_BLACK_NO_ALPHA		(COLOR(0.0f,0.0f,0.0f,0.0f))			// ��
#define COLOR_RED_NO_ALPHA			(COLOR(1.0f,0.0f,0.0f,0.0f))			// ��
#define COLOR_GREEN_NO_ALPHA		(COLOR(0.0f,1.0f,0.0f,0.0f))			// ��
#define COLOR_BLUE_NO_ALPHA			(COLOR(0.0f,0.0f,1.0f,0.0f))			// ��
#define COLOR_YELLOW_NO_ALPHA		(COLOR(1.0f,1.0f,0.0f,0.0f))			// ���F
#define COLOR_PURPLE_NO_ALPHA		(COLOR(1.0f,0.0f,1.0f,0.0f))			// ��
#define COLOR_SKYBLUE_NO_ALPHA		(COLOR(0.0f,1.0f,1.0f,0.0f))			// ���F

#define LIGHTCOLR_WHILE_NO_ALPHA	(COLOR(0.5f,0.5f,0.5f,0.0f))			// ������
#define LIGHTCOLOR_RED_NO_ALPHA		(COLOR(0.5f,0.0f,0.0f,0.0f))			// ������
#define LIGHTCOLOR_GREEN_NO_ALPHA	(COLOR(0.0f,0.5f,0.0f,0.0f))			// ������
#define LIGHTCOLOR_BLUE_NO_ALPHA	(COLOR(0.0f,0.0f,0.5f,0.0f))			// ������
#define LIGHTCOLOR_YELLOW_NO_ALPHA	(COLOR(0.5f,0.5f,0.0f,0.0f))			// �������F
#define LIGHTCOLOR_PURPLE_NO_ALPHA	(COLOR(0.5f,0.0f,0.5f,0.0f))			// ������
#define LIGHTCOLOR_SKYBLUE_NO_ALPHA	(COLOR(0.0f,0.5f,0.5f,0.0f))			// �������F

//*****************************************************************************
// �N���X��`
//*****************************************************************************

//*****************************************************************************
// �\���̒�`
//*****************************************************************************
// �F�\����
struct COLOR
{
	COLOR(){};
	COLOR(float fr,float fg,float fb,float fa);
	COLOR(COLOR c1,COLOR c2);

	COLOR operator * ( float cf) const;
	COLOR operator / ( float cf) const;
	COLOR operator + ( COLOR& c) const;
	COLOR operator - ( COLOR& c) const;
	COLOR operator * ( COLOR& c) const;
	COLOR operator + () const;
	COLOR operator - () const;
	COLOR& operator -= (const COLOR& c);
	COLOR& operator += (const COLOR& c);
	COLOR& operator *= ( float f);
	COLOR& operator /= ( float f);
	operator DWORD ()const;
	//operator COLOR ()const;
	COLOR operator + (COLOR c) const;
	COLOR operator - (COLOR c) const;
	float r,g,b,a;			// �F
	
};

//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************
inline float RandFloat(void);
inline float RandomClamped(void);
void RandomColor(COLOR *color);				// �����_���ȐF���擾
#endif
// EOF