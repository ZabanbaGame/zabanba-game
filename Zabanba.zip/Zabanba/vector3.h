//=============================================================================
//
// �x�N�g��3D [VECTOR3.h]
// Author : KOUTAROU NISIDA
//
//=============================================================================
#ifndef _VECTOR3_H_		// �C���N���[�h�K�[�h
#define _VECTOR3_H_

//*****************************************************************************
// �C���N���[�h�t�@�C��
//*****************************************************************************

//*****************************************************************************
// ���C�u�����̃����N
//*****************************************************************************

//*****************************************************************************
// �}�N����`
//*****************************************************************************
#define VECTOR_ZERO ( VECTOR3(0.0f,0.0f,0.0f) )	// �x�N�g���̒l�����ׂ�0�ɂ���

//*****************************************************************************
// �N���X��`
//*****************************************************************************

//*************************************
// �x�N�g��3D
//*************************************

struct D3DXVECTOR3;

//*****************************************************************************
// �\���̒�`
//*****************************************************************************
struct VECTOR3
{
public:
	VECTOR3(){};
	VECTOR3(float fx,float fy,float fz);
	VECTOR3 operator * ( float vf) const;
	VECTOR3 operator / ( float vf) const;
	VECTOR3 operator + ( VECTOR3& v) const;
	VECTOR3 operator - ( VECTOR3& v) const;
	VECTOR3 operator * ( VECTOR3& v) const;
	VECTOR3 operator + () const;
	VECTOR3 operator - () const;
	VECTOR3& operator -= (const VECTOR3& v);
	VECTOR3& operator += (const VECTOR3& v);
	VECTOR3& operator += ( float f);
	VECTOR3& operator *= ( float f);
	VECTOR3& operator /= ( float f);
	VECTOR3& operator *= ( VECTOR3 v);
	operator D3DXVECTOR3 ()const;

	//=============================================================================
	// ���K��
	// ����:��
	// �ߒl:��
	//=============================================================================
	void Normalixe(void);		// ���K��

	//=============================================================================
	// �ʖ@��
	// �O�ςŋ��߂�ꂽ�x�N�g��
	// �ʖ@���x�N�g��
	//=============================================================================
	VECTOR3 SurfaceNormali( const VECTOR3& vec);

	// ���ϑ��x
	VECTOR3 AverageSpeed(const VECTOR3& StartPos,const VECTOR3& EndPos,float interval );

	float x,y,z;
};

//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************
float Vector3Length(VECTOR3& vec);
VECTOR3 Vector3Normalixe(VECTOR3& out,VECTOR3& vec);
float Vector3Dot(VECTOR3& vecL,VECTOR3& vecR);
VECTOR3 Vector3Cross(VECTOR3& vecL,VECTOR3& vecR);
float AngleBetween(VECTOR3& vecL,VECTOR3& vecR);
VECTOR3 Vector3SurfaceNormali( VECTOR3& vecL,VECTOR3& vecR);

#endif
// EOF