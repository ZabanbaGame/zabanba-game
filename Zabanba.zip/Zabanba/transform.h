//==============================================================================
// 
// �ϊ�[transform.h]
// Auther: KOUTAROU NISIDA
// 
//==============================================================================

//==============================================================================
// �C���N���[�h�K�[�h
//==============================================================================
#ifndef __TRANSFORM_H_
#define __TRANSFORM_H_
//==============================================================================
// �C���N���[�h
//==============================================================================
#include "vector2.h"
#include "vector3.h"
#include "matrix.h"

//==============================================================================
// �}�N����`
//==============================================================================

//==============================================================================
// �N���X
//==============================================================================
class Transform
{
public:
	Transform();
	~Transform();
	void Init(void);
	void Uninit(void);
	void Update(void);
	void Draw(void);

	void AddRotation( VECTOR3 value );
	void AddRotation( float xvalue,float yvalue,float zvalue );
	void SubRotation( VECTOR3 value );
	void SubRotation( float xvalue,float yvalue,float zvalue );

	void CreateScalingMatrix(MATRIX4 *out,MATRIX4 *source);
	void CreateScalingMatrix(MATRIX4 *out,MATRIX4 *source,float x, float y, float z);

	void CreateRoationMatrix(MATRIX4 *out,MATRIX4 *source);
	void CreateRoationMatrix(MATRIX4 *out,MATRIX4 *source,float yaw, float pitch, float roll);

	void CreateTranslationMatrix(MATRIX4 *out,MATRIX4 *source);
	void CreateTranslationMatrix(MATRIX4 *out,MATRIX4 *source,float x, float y, float z);

	void Scaling(MATRIX4 *out,float x, float y, float z);
	void RotationYawPitchRoll(MATRIX4 *out,float yaw, float pitch, float roll);
	void Translation(MATRIX4 *out,float x, float y, float z);

	void SetPosition(float x,float y,float z){ m_Position.x = x; m_Position.y = y; m_Position.z = z; }
	void SetPosition(VECTOR3 position);
	VECTOR3 GetPosition(void){ return m_Position; }

	VECTOR3 m_Position;
	VECTOR3 m_Rotation;
	VECTOR3 m_Scale;
	MATRIX4 m_Matrix4;

	Transform& operator = (const Transform& transform);
};

//==============================================================================
// �\���̒�`
//==============================================================================

//==============================================================================
// �v���g�^�C�v�錾
//==============================================================================
#endif
// EOF