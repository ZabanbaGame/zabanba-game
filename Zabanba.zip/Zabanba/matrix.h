//==============================================================================
// 
// 4x4�}�g���b�N�X[matrix.h]
// Auther: KOUTAROUNISIDA
// 
//==============================================================================

//==============================================================================
// �C���N���[�h�K�[�h
//==============================================================================
#ifndef __MATRIX_H_
#define __MATRIX_H_
//==============================================================================
// �C���N���[�h
//==============================================================================
#include "vector3.h"

//==============================================================================
// �}�N����`
//==============================================================================

//==============================================================================
// �N���X
//==============================================================================

struct D3DXMATRIX;

//*************************************
// 3x3�s��\����
//*************************************
struct MATRIX3
{
public:
	MATRIX3(){};
	MATRIX3(float f11,float f12,float f13,
		   float f21,float f22,float f23,
		   float f31,float f32,float f33);
	void Identity(MATRIX3 *out);
	void Translation(MATRIX3 *out,VECTOR3 *pos);
	void Scaling( MATRIX3 *out, VECTOR3 *scl );
	void Rotation(MATRIX3 *out, float fAngle );
	void Multiply( MATRIX3 *Out, MATRIX3 *Matrix1, MATRIX3 *Matrix2 );

	void Vector3Transform( VECTOR3 *Out, VECTOR3 *Vector, MATRIX3 *Matrix );

	// ���Z�q�̃I�[�o�[���[�h
	MATRIX3 operator + (const MATRIX3& Mat) const;
	MATRIX3 operator * (float f) const;
	MATRIX3 operator * (const MATRIX3& Mat) const;

	float m11,m12,m13;
	float m21,m22,m23;
	float m31,m32,m33;
};

//*************************************
// 4x4�s��\����
//*************************************
struct MATRIX4
{
public:
	MATRIX4(){};
	MATRIX4(float f11,float f12,float f13,float f14,
		   float f21,float f22,float f23,float f24,
		   float f31,float f32,float f33,float f34,
		   float f41,float f42,float f43,float f44);

	// ���Z�q�̃I�[�o�[���[�h
	MATRIX4 operator + (const MATRIX4& Mat) const;
	MATRIX4 operator * (float f) const;
	MATRIX4 operator * (const MATRIX4& Mat) const;

	operator D3DXMATRIX ()const;
	
	union
	{
		struct
		{
			float m11,m12,m13,m14;
			float m21,m22,m23,m24;
			float m31,m32,m33,m34;
			float m41,m42,m43,m44;
		};
		float f[16];
		float M[4][4];
	};

};

//==============================================================================
// �\���̒�`
//==============================================================================

//==============================================================================
// �v���g�^�C�v�錾
//==============================================================================
void Matrix4Identity(MATRIX4 *out);
void Matrix4Translation(MATRIX4 *out,float x,float y,float z);					// �ړ�
void Matrix4Scaling( MATRIX4 *out,float x,float y,float z );	// �X�P�[��

void Matrix4Multiply( MATRIX4 *Out, MATRIX4 *Matrix1, MATRIX4 *Matrix2 );

void Matrix4Vector3Transform( VECTOR3 *Out, VECTOR3 *Vector, MATRIX4 *Matrix );
void Matrix4Zero(MATRIX4 *Out );
void Matrix4Transpose( MATRIX4 *Out, MATRIX4 *Matrix1 );
void Matrix4Inverse(MATRIX4 *Out,MATRIX4 *Matrix);
void Matrix4CreateRotation(MATRIX4 *Out,float thetaX,float thetaY,float thetaZ);
void Matrix4RotationYawPitchRoll(MATRIX4 *Out, float yaw, float pitch, float roll);
#endif
// EOF