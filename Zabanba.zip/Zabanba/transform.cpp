//==============================================================================
// 
// �ϊ�[transform.cpp]
// Auther: KOUTAROU NISIDA
// 
//==============================================================================

//==============================================================================
// �C���N���[�h
//==============================================================================
#include "transform.h"
//==============================================================================
// �}�N����`
//==============================================================================

//==============================================================================
// �N���X
//==============================================================================

//==============================================================================
// �\���̒�`
//==============================================================================

//==============================================================================
// �O���[�o���ϐ�
//==============================================================================

//==============================================================================
// �ÓI�ϐ�
//==============================================================================

//==============================================================================
// �v���g�^�C�v�錾
//==============================================================================

//==============================================================================
// �ϊ��R���X�g���N�^
// ����:
// �ߒl:
//==============================================================================
Transform::Transform()
{
	m_Position = VECTOR_ZERO;
	m_Rotation = VECTOR_ZERO;
	m_Scale = VECTOR_ZERO;

}

//==============================================================================
// �ϊ��f�X�g���N�^
// ����:
// �ߒl:
//==============================================================================
Transform::~Transform()
{
}

//==============================================================================
// �ϊ�����������
// ����:
// �ߒl:
//==============================================================================
void Transform::Init(void)
{
	m_Position = VECTOR_ZERO;
	m_Rotation = VECTOR_ZERO;
	m_Scale = VECTOR3(1.0f,1.0f,1.0f);
}

//==============================================================================
// �ϊ��I������
// ����:��
// �ߒl:��
//==============================================================================
void Transform::Uninit(void)
{
}

//==============================================================================
// �ϊ��X�V����
// ����:��
// �ߒl:��
//==============================================================================
void Transform::Update(void)
{
}

//==============================================================================
// �ϊ��`�揈��
// ����:��
// �ߒl:��
//==============================================================================
void Transform::Draw(void)
{
}

//=============================================================================
// �ϊ��̑��
// ����:
// �ߒl:
//=============================================================================
Transform& Transform::operator=( const Transform& transform )
{
	m_Position = transform.m_Position;
	m_Rotation = transform.m_Rotation;
	m_Scale = transform.m_Scale;
	return *this;
}

//=============================================================================
// ��]�̉��Z
// ����:
// �ߒl:
//=============================================================================
void Transform::AddRotation( VECTOR3 value )
{
	m_Rotation += value;

	if( m_Rotation.x < -PI )
	{
		m_Rotation.x += PI*2;
	}
	else if( m_Rotation.x > PI )
	{
		m_Rotation.x -= PI*2;
	}

	if( m_Rotation.y < -PI )
	{
		m_Rotation.y += PI*2;
	}
	else if( m_Rotation.y > PI )
	{
		m_Rotation.y -= PI*2;
	}

	if( m_Rotation.z < -PI )
	{
		m_Rotation.z += PI*2;
	}
	else if( m_Rotation.z > PI )
	{
		m_Rotation.z -= PI*2;
	}
}

//=============================================================================
// ��]�̉��Z
// ����:
// �ߒl:
//=============================================================================
void Transform::AddRotation( float xvalue,float yvalue,float zvalue )
{
	m_Rotation.x += xvalue;
	m_Rotation.y += yvalue;
	m_Rotation.z += zvalue;

	if( m_Rotation.x < -PI )
	{
		m_Rotation.x += PI*2;
	}
	else if( m_Rotation.x > PI )
	{
		m_Rotation.x -= PI*2;
	}

	if( m_Rotation.y < -PI )
	{
		m_Rotation.y += PI*2;
	}
	else if( m_Rotation.y > PI )
	{
		m_Rotation.y -= PI*2;
	}

	if( m_Rotation.z < -PI )
	{
		m_Rotation.z += PI*2;
	}
	else if( m_Rotation.z > PI )
	{
		m_Rotation.z -= PI*2;
	}
}

//=============================================================================
// ��]�̌��Z
// ����:
// �ߒl:
//=============================================================================
void Transform::SubRotation( VECTOR3 value )
{
	m_Rotation -= value;

	if( m_Rotation.x < -PI )
	{
		m_Rotation.x += PI*2;
	}
	else if( m_Rotation.x > PI )
	{
		m_Rotation.x -= PI*2;
	}

	if( m_Rotation.y < -PI )
	{
		m_Rotation.y += PI*2;
	}
	else if( m_Rotation.y > PI )
	{
		m_Rotation.y -= PI*2;
	}

	if( m_Rotation.z < -PI )
	{
		m_Rotation.z += PI*2;
	}
	else if( m_Rotation.z > PI )
	{
		m_Rotation.z -= PI*2;
	}
}

//=============================================================================
// ��]�̌��Z
// ����:
// �ߒl:
//=============================================================================
void Transform::SubRotation( float xvalue,float yvalue,float zvalue )
{
	m_Rotation.x -= xvalue;
	m_Rotation.y -= yvalue;
	m_Rotation.z -= zvalue;

	if( m_Rotation.x < -PI )
	{
		m_Rotation.x += PI*2;
	}
	else if( m_Rotation.x > PI )
	{
		m_Rotation.x -= PI*2;
	}

	if( m_Rotation.y < -PI )
	{
		m_Rotation.y += PI*2;
	}
	else if( m_Rotation.y > PI )
	{
		m_Rotation.y -= PI*2;
	}

	if( m_Rotation.z < -PI )
	{
		m_Rotation.z += PI*2;
	}
	else if( m_Rotation.z > PI )
	{
		m_Rotation.z -= PI*2;
	}
}


//=============================================================================
// �X�P�[�����O
// ����:
// �ߒl:
//=============================================================================
void Transform::Scaling(MATRIX4 *out,float x, float y, float z)
{
	Matrix4Scaling(out,x,y,z);
}

//=============================================================================
// ��]
// ����:
// �ߒl:
//=============================================================================
void Transform::RotationYawPitchRoll(MATRIX4 *out,float yaw, float pitch, float roll)
{
	Matrix4RotationYawPitchRoll(out,yaw,pitch,roll);
}

//=============================================================================
// �ړ�
// ����:
// �ߒl:
//=============================================================================
void Transform::Translation(MATRIX4 *out,float x, float y, float z)
{
	Matrix4Translation(out,x,y,z);
}


//=============================================================================
// �X�P�[���s��̐���
// ����:
// �ߒl:
//=============================================================================
void Transform::CreateScalingMatrix(MATRIX4 *out,MATRIX4 *source)
{
	MATRIX4 scal;
	this->Scaling(&scal,m_Scale.x,m_Scale.y,m_Scale.z);
	Matrix4Multiply(out,out,&scal);
}

//=============================================================================
// �X�P�[���s��̐���
// ����:
// �ߒl:
//=============================================================================
void Transform::CreateScalingMatrix(MATRIX4 *out,MATRIX4 *source,float x, float y, float z)
{
	MATRIX4 scal;
	this->Scaling(&scal,x,y,z);
	Matrix4Multiply(out,out,&scal);
}

//=============================================================================
// ��]�s��̐���
// ����:
// �ߒl:
//=============================================================================
void Transform::CreateRoationMatrix(MATRIX4 *out,MATRIX4 *source)
{
	MATRIX4 rotation;
	this->RotationYawPitchRoll(&rotation,m_Rotation.y,m_Rotation.x,m_Rotation.z);
	Matrix4Multiply(out,out,&rotation);
}

//=============================================================================
// ��]�s��̐���
// ����:
// �ߒl:
//=============================================================================
void Transform::CreateRoationMatrix(MATRIX4 *out,MATRIX4 *source,float yaw, float pitch, float roll)
{
	MATRIX4 rotation;
	this->RotationYawPitchRoll(&rotation,yaw,pitch,roll);
	Matrix4Multiply(out,out,&rotation);
}

//=============================================================================
// �ړ��s��̐���
// ����:
// �ߒl:
//=============================================================================
void Transform::CreateTranslationMatrix(MATRIX4 *out,MATRIX4 *source)
{
	MATRIX4 trans;
	this->Translation(&trans,m_Position.x,m_Position.y,m_Position.z);
	Matrix4Multiply(out,out,&trans);
}

//=============================================================================
// �ړ��s��̐���
// ����:
// �ߒl:
//=============================================================================
void Transform::CreateTranslationMatrix(MATRIX4 *out,MATRIX4 *source,float x, float y, float z)
{
	MATRIX4 trans;
	this->Translation(&trans,x,y,z);
	Matrix4Multiply(out,out,&trans);
}
// EOF