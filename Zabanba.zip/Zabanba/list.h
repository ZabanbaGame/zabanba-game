//==============================================================================
// 
// ���X�g[list.h]
// Auther: KOUTAROUNISIDA
// 
//==============================================================================

//==============================================================================
// �C���N���[�h�K�[�h
//==============================================================================
#ifndef __LIST_H_
#define __LIST_H_
//==============================================================================
// �C���N���[�h
//==============================================================================
#include "node.h"
#include <stdio.h>

//==============================================================================
// �}�N����`
//==============================================================================
#define ADD_LIST_SIZE (1)
#define SUB_LIST_SIZE (-1)

//==============================================================================
// �N���X
//==============================================================================

template <typename T>
class List
{
public:
	List();
	~List();
	void ReleaseAll(void);
	void LinkList(T data);
	T UnLinkList(int index);

	T get(int index);
	NODE<T> *serchNode(int index);
	int GetSize(void){ return m_Size; }


private :
	void AddSize(int size){ m_Size += size; }
	void SubSize(int size){ m_Size -= size; }

	NODE<T> *m_Top;
	NODE<T> *m_Current;
	int m_Size;
};

//==============================================================================
// �\���̒�`
//==============================================================================

//==============================================================================
// �v���g�^�C�v�錾
//==============================================================================
//==============================================================================
// ���X�g�R���X�g���N�^
// ����:
// �ߒl:
//==============================================================================
template <typename T>
List<T>::List()
{
	m_Top = NULL;
	m_Current = NULL;
	m_Size = 0;
}

//==============================================================================
// ���X�g�f�X�g���N�^
// ����:
// �ߒl:
//==============================================================================
template <typename T>
List<T>::~List()
{
}

//==============================================================================
// ���X�g�̒ǉ�
// ����:
// �ߒl:
//==============================================================================
template <typename T>
void List<T>::LinkList( T data )
{
	// �m�[�h����
	NODE<T> *NewNode = new NODE<T>();
	NewNode->Data = data;
	NewNode->Prev = NULL;

	if( m_Current != NULL )
	{
		// �m�[�h�̒ǉ�
		m_Current->Next = NewNode;
		NewNode->Prev = m_Current;
		m_Current = NewNode;
	}
	else
	{
		// �擪�����݂��Ȃ�
		m_Top = m_Current = NewNode;
		m_Top->Prev = NULL;
	}

	AddSize(ADD_LIST_SIZE);
}

//==============================================================================
// ���X�g�̑S�폜
// ����:
// �ߒl:
//==============================================================================
template <typename T>
void List<T>::ReleaseAll()
{
	NODE<T> *list = m_Top;
	while( list )
	{
		NODE<T> *next = list->Next;

		if( list != NULL )
		{
			delete list ;
			list = NULL;
		}
		list = next;
	}
}

//==============================================================================
// ���X�g�̓o�^�w�����
// ����: int index : �Y����
// �ߒl:
//==============================================================================
template <typename T>
T List<T>::UnLinkList(int index)
{
	//NODE *list = m_Top;
	NODE<T> *list = serchNode(index);

	if( list != NULL )
	{
		if( list->Prev != NULL )
		{// �擪�ȊO
			list->Prev->Next = list->Next;
		}
		else
		{// �擪�̉���
			m_Top = list->Next;
		}

		if( list->Next != NULL )
		{
			list->Next->Prev = list->Prev;
		}
	}
	AddSize(SUB_LIST_SIZE);
	T data = list->Data;
	delete list;

	return data;
}

//==============================================================================
// ���X�g�̒l�擾
// ����:
// �ߒl:
//==============================================================================
template <typename T>
T List<T>::get(int index)
{
	return serchNode(index)->Data;
}

//==============================================================================
// ���X�g�̃m�[�h�̒T��
// ����:
// �ߒl:
//==============================================================================
template <typename T>
NODE<T> *List<T>::serchNode(int index)
{
	NODE<T> *nodeList = m_Top;
	NODE<T> *result = NULL;
	int cnt = 0;
	while( nodeList )
	{
		NODE<T> *next = nodeList->Next;

		if( cnt == index )
		{
			if( nodeList != NULL )
			{
				result = nodeList;
				break;
			}
		}
		nodeList = next;
		cnt++;
	}
	return result;
}
#endif
// EOF