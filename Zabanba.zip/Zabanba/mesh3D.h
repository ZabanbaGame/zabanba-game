//==============================================================================
// 
// ���b�V��3D[mesh3D.h]
// Auther: KOUTAROUNISIDA
// 
//==============================================================================

//==============================================================================
// �C���N���[�h�K�[�h
//==============================================================================
#ifndef __MESH3D_H_
#define __MESH3D_H_
//==============================================================================
// �C���N���[�h
//==============================================================================
#include "rendererComposition.h"
#include "common.h"

//==============================================================================
// �}�N����`
//==============================================================================

//==============================================================================
// �N���X
//==============================================================================
class Mesh3DData;

class Mesh3D: public RendererComposition
{
public:
	Mesh3D(GameObject *gameobject);
	~Mesh3D();
	HRESULT Init(float width,float height , float depth);
	void Uninit(void);
	void Update(void);
	void Draw(void);

	static Mesh3D *Create(GameObject *gameobject,float width,float height , float depth);

	void InitVertex(float width, float height, float depth);
	void SetVertex(float width, float height, float depth);
	
	void SetColor(COLOR color);

	void SetNormal(int novtx,VECTOR3 normal);
	void SetTexCoord(float top, float bottom, float left, float right);

private:
	float		m_Width;		// ��
	float		m_Height;		// ����
	float		m_Depth;		// ���s��
	VECTOR3		m_RotDest;		// �ړI�̊p�x

	Mesh3DData	*m_Mesh3DData;		// ���b�V��3D�f�[�^�[
};

//==============================================================================
// �\���̒�`
//==============================================================================

//==============================================================================
// �v���g�^�C�v�錾
//==============================================================================
#endif
// EOF